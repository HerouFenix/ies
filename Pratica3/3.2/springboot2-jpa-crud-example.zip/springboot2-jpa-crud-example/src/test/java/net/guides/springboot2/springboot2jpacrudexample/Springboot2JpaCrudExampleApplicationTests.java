package net.guides.springboot2.springboot2jpacrudexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot2JpaCrudExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
